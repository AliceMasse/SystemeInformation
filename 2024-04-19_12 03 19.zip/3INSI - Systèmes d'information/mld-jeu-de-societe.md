# MLD

editeur(**code_editeur**, nom_editeur)

magasin_en_ligne(**code_magasin**, nom_magasin)

jeu_de_societe(**code_jeu_de_societe**, nom_jeu_de_societe,nb_de_joueurs, _code_editeur_, _code_magasin_)

client(**code_client**, nom_client)

achat(_code_client_,_code_jeu_de_societe_date_achat,quantite)